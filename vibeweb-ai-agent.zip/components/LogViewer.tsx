
import React, { useEffect, useRef } from 'react';
import { ActionLog } from '../types';
import { Terminal, Search, MousePointer2, Globe, Cpu, Info } from 'lucide-react';

interface LogViewerProps {
  logs: ActionLog[];
}

const LogViewer: React.FC<LogViewerProps> = ({ logs }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const getIcon = (type: ActionLog['type']) => {
    switch (type) {
      case 'think': return <Cpu className="w-4 h-4 text-purple-400" />;
      case 'search': return <Search className="w-4 h-4 text-blue-400" />;
      case 'navigate': return <Globe className="w-4 h-4 text-emerald-400" />;
      case 'click': return <MousePointer2 className="w-4 h-4 text-orange-400" />;
      case 'read': return <Terminal className="w-4 h-4 text-pink-400" />;
      default: return <Info className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#111] border border-white/10 rounded-lg overflow-hidden font-mono text-sm">
      <div className="px-4 py-2 bg-white/5 border-b border-white/10 flex items-center justify-between">
        <span className="text-white/60 font-medium">EXECUTION_LOG</span>
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
        </div>
      </div>
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-3 scroll-smooth"
      >
        {logs.length === 0 && (
          <div className="text-white/20 italic">Waiting for instructions...</div>
        )}
        {logs.map((log) => (
          <div key={log.id} className="animate-in fade-in slide-in-from-left-2 duration-300">
            <div className="flex items-start gap-3">
              <span className="mt-0.5">{getIcon(log.type)}</span>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <span className={`uppercase font-bold text-[10px] tracking-widest ${
                    log.type === 'think' ? 'text-purple-400' :
                    log.type === 'search' ? 'text-blue-400' :
                    log.type === 'navigate' ? 'text-emerald-400' :
                    'text-white/60'
                  }`}>
                    {log.type}
                  </span>
                  <span className="text-[10px] text-white/30">
                    {log.timestamp.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
                <p className="text-white/80 leading-relaxed">{log.message}</p>
                {log.details && (
                  <p className="text-white/40 text-xs mt-1 truncate max-w-full">
                    {log.details}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Lucide React Icons (Standalone versions as they aren't imported standard)
// These icons are included via lucide-react in the package
export default LogViewer;
