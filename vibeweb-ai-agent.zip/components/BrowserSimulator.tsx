
import React, { useState, useEffect } from 'react';
import { GroundingSource } from '../types';
import { ArrowLeft, ArrowRight, RotateCcw, Home, Lock, ExternalLink, Search, Globe, Layout, ShieldCheck, Zap } from 'lucide-react';

interface BrowserSimulatorProps {
  url: string;
  title: string;
  sources: GroundingSource[];
  isThinking: boolean;
  content: string;
}

const BrowserSimulator: React.FC<BrowserSimulatorProps> = ({ url, title, sources, isThinking, content }) => {
  const [activeTab, setActiveTab] = useState(-1);

  useEffect(() => {
    if (sources.length > 0 && activeTab === -1 && isThinking) {
      // Stay on agent tab while thinking, but maybe switch when done?
      // For now, let's just ensure we don't crash.
    }
  }, [sources, isThinking]);

  // If a tab was selected but sources changed/cleared, fallback to agent tab
  const currentSource = activeTab >= 0 ? sources[activeTab] : null;

  return (
    <div className="flex flex-col h-full bg-[#0d0d0d] rounded-xl border border-white/10 shadow-2xl overflow-hidden ring-1 ring-white/5">
      {/* Tab Bar */}
      <div className="bg-[#1a1a1a] flex items-end px-2 pt-2 gap-1 overflow-x-auto no-scrollbar">
        <div 
          onClick={() => setActiveTab(-1)}
          className={`flex items-center gap-2 px-4 py-2 rounded-t-lg cursor-pointer transition-all min-w-[140px] max-w-[200px] border-t border-x ${activeTab === -1 ? 'bg-[#252525] border-white/10 text-white' : 'bg-transparent border-transparent text-white/40 hover:bg-white/5'}`}
        >
          <Zap className={`w-3 h-3 ${activeTab === -1 ? 'text-indigo-400' : ''}`} />
          <span className="text-xs font-medium truncate">VibeWeb Agent</span>
        </div>
        
        {sources.map((source, idx) => (
          <div 
            key={idx}
            onClick={() => setActiveTab(idx)}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-lg cursor-pointer transition-all min-w-[140px] max-w-[200px] border-t border-x ${activeTab === idx ? 'bg-[#252525] border-white/10 text-white' : 'bg-transparent border-transparent text-white/40 hover:bg-white/5'}`}
          >
            <Globe className="w-3 h-3 text-emerald-500" />
            <span className="text-xs font-medium truncate">{source.title}</span>
          </div>
        ))}
      </div>

      {/* Browser Toolbar */}
      <div className="bg-[#252525] border-b border-white/5 p-2 flex items-center gap-3">
        <div className="flex items-center gap-3 px-2">
          <ArrowLeft className="w-4 h-4 text-white/20" />
          <ArrowRight className="w-4 h-4 text-white/20" />
          <RotateCcw className={`w-4 h-4 text-white/60 cursor-pointer ${isThinking ? 'animate-spin text-indigo-400' : ''}`} />
          <Home className="w-4 h-4 text-white/60 cursor-pointer" />
        </div>
        
        <div className="flex-1 bg-black/60 rounded-lg py-1.5 px-4 flex items-center gap-3 border border-white/5 group">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span className="text-sm text-white/70 truncate font-mono select-all">
            {isThinking ? 'https://google.com/search?q=...' : (activeTab === -1 ? 'vibeweb://agent-core' : (currentSource?.uri || 'vibeweb://loading'))}
          </span>
          <div className="flex-1" />
          <Search className="w-3.5 h-3.5 text-white/20 group-hover:text-white/40 transition-colors" />
        </div>

        <div className="flex items-center gap-2 px-2">
           <div className="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-2 py-1 rounded border border-indigo-500/20 uppercase tracking-wider">
             HTTP/3 Live
           </div>
        </div>
      </div>

      {/* Browser Content */}
      <div className="flex-1 overflow-y-auto bg-white p-0 relative">
        {isThinking ? (
          <div className="flex flex-col items-center justify-center h-full bg-[#f8fafc]">
            <div className="w-full max-w-2xl px-8 space-y-8">
              <div className="flex items-center gap-4 text-4xl font-black italic tracking-tighter opacity-10 grayscale select-none pointer-events-none">
                <span className="text-blue-600">V</span><span className="text-red-500">I</span><span className="text-yellow-500">B</span><span className="text-blue-600">E</span><span className="text-green-500">W</span><span className="text-red-500">E</span><span className="text-indigo-600">B</span>
              </div>
              
              <div className="relative">
                <div className="h-14 w-full bg-white rounded-2xl shadow-xl shadow-indigo-500/5 border border-slate-200 flex items-center px-6">
                  <Search className="w-6 h-6 text-slate-300 mr-4" />
                  <div className="h-2 w-48 bg-slate-100 rounded-full animate-pulse" />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 pt-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="bg-white p-4 rounded-xl border border-slate-100 space-y-3 shadow-sm">
                    <div className="h-4 w-64 bg-slate-100 rounded animate-pulse" />
                    <div className="space-y-2">
                      <div className="h-2 w-full bg-slate-50 rounded animate-pulse" />
                      <div className="h-2 w-4/5 bg-slate-50 rounded animate-pulse" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="absolute bottom-12 flex items-center gap-3 px-6 py-3 bg-indigo-600 text-white rounded-full shadow-2xl shadow-indigo-600/40 animate-bounce">
              <RotateCcw className="w-4 h-4 animate-spin" />
              <span className="text-sm font-bold tracking-tight">Agente Navegando em Tempo Real...</span>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col">
            {activeTab === -1 || !currentSource ? (
              <div className="flex-1 overflow-y-auto bg-slate-50 p-8">
                <div className="max-w-4xl mx-auto">
                  {content ? (
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-10 animate-in fade-in slide-in-from-bottom-6 duration-700">
                      <div className="flex items-center gap-2 mb-6">
                        <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
                          <Zap className="w-5 h-5 text-white fill-current" />
                        </div>
                        <h2 className="text-xs font-black uppercase tracking-[0.2em] text-indigo-600">Relatório de Navegação</h2>
                      </div>
                      <h1 className="text-4xl font-black text-slate-900 mb-8 leading-tight tracking-tight">
                        {title || "Exploração Finalizada"}
                      </h1>
                      <div className="prose prose-lg prose-slate max-w-none text-slate-700 leading-relaxed whitespace-pre-wrap">
                        {content}
                      </div>
                      
                      <div className="mt-16 pt-10 border-t border-slate-100">
                        <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2">
                          <Layout className="w-4 h-4" /> Pontos de Verificação Visual
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {sources.map((s, idx) => (
                            <div 
                              key={idx}
                              onClick={() => setActiveTab(idx)}
                              className="group cursor-pointer p-4 bg-slate-50 border border-slate-200 rounded-xl hover:bg-indigo-50 hover:border-indigo-200 transition-all"
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-bold text-slate-900 truncate group-hover:text-indigo-600">{s.title}</p>
                                  <p className="text-[10px] text-slate-400 truncate mt-1">{s.uri}</p>
                                </div>
                                <ExternalLink className="w-4 h-4 text-slate-300 group-hover:text-indigo-500" />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[60vh] text-slate-300 space-y-6">
                      <div className="relative">
                        <div className="w-24 h-24 rounded-3xl bg-indigo-600 flex items-center justify-center shadow-2xl shadow-indigo-600/20 rotate-3">
                           <Globe className="w-12 h-12 text-white" />
                        </div>
                        <div className="absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-lg border border-slate-100">
                           <Search className="w-5 h-5 text-indigo-600" />
                        </div>
                      </div>
                      <div className="text-center space-y-2">
                        <h2 className="text-2xl font-black text-slate-800">Pronto para Navegar</h2>
                        <p className="text-slate-500 max-w-sm font-medium">
                          Insira um comando para que o VibeWeb explore a internet real para você.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col bg-white">
                <div className="bg-emerald-50 text-emerald-700 px-6 py-4 border-b border-emerald-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="w-5 h-5" />
                    <span className="font-bold text-sm italic">Visualizando snapshot da página real capturada pelo agente</span>
                  </div>
                  <button 
                    onClick={() => currentSource?.uri && window.open(currentSource.uri, '_blank')}
                    className="flex items-center gap-2 bg-white px-4 py-1.5 rounded-lg border border-emerald-200 text-xs font-bold hover:bg-emerald-100 transition-colors shadow-sm"
                  >
                    Abrir em nova aba <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
                <div className="flex-1 p-10 overflow-y-auto">
                   <div className="max-w-4xl mx-auto space-y-8">
                      <div className="space-y-4">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-500 text-[10px] font-bold uppercase tracking-widest">
                          Source Metadata
                        </div>
                        <h1 className="text-5xl font-black text-slate-900 leading-tight tracking-tighter">
                          {currentSource?.title}
                        </h1>
                        <p className="text-indigo-600 font-mono text-sm break-all bg-indigo-50 p-2 rounded border border-indigo-100">
                          {currentSource?.uri}
                        </p>
                      </div>
                      
                      <div className="p-8 rounded-3xl bg-slate-50 border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center space-y-6 py-20">
                         <div className="w-16 h-16 rounded-2xl bg-white shadow-xl flex items-center justify-center">
                            <Layout className="w-8 h-8 text-slate-300" />
                         </div>
                         <div className="space-y-2">
                           <h3 className="text-xl font-bold text-slate-800">Visualização de Segurança Ativada</h3>
                           <p className="text-slate-500 max-w-md mx-auto">
                             O agente VibeWeb processou o conteúdo desta página de forma segura. O resumo e as informações extraídas estão disponíveis na aba principal "VibeWeb Agent".
                           </p>
                         </div>
                         <button 
                          onClick={() => setActiveTab(-1)}
                          className="bg-slate-900 text-white px-8 py-3 rounded-2xl font-bold hover:scale-105 transition-transform"
                         >
                            Voltar para o Relatório do Agente
                         </button>
                      </div>
                   </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BrowserSimulator;
