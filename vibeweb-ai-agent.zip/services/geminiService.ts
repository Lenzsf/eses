
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ActionLog, GroundingSource } from "../types";

const MODEL_NAME = 'gemini-3-pro-preview';

export const navigateWeb = async (
  prompt: string, 
  onLog: (log: ActionLog) => void,
  onSources: (sources: GroundingSource[]) => void
): Promise<{ text: string; sources: GroundingSource[] }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  onLog({
    id: Math.random().toString(),
    type: 'think',
    message: `Iniciando agente de navegação para: "${prompt}"`,
    timestamp: new Date()
  });

  try {
    onLog({
      id: Math.random().toString(),
      type: 'search',
      message: `Solicitando acesso ao motor de busca em tempo real...`,
      timestamp: new Date()
    });

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Você é o VibeWeb, um agente autônomo que navega na internet. 
      Sua tarefa atual é: ${prompt}. 
      Use a ferramenta de busca para encontrar as informações mais recentes e precisas. 
      Retorne uma resposta detalhada e estruturada com o que encontrar.`,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 8000 }
      },
    });

    const text = response.text || "Não foi possível processar a requisição.";
    
    // Extract grounding sources
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources: GroundingSource[] = chunks
      .filter(c => c.web)
      .map(c => ({
        title: c.web.title || 'Página Web',
        uri: c.web.uri
      }));
    
    onSources(sources);

    if (sources.length > 0) {
      onLog({
        id: Math.random().toString(),
        type: 'info',
        message: `Busca concluída. Encontradas ${sources.length} fontes relevantes.`,
        timestamp: new Date()
      });

      // Simulation of step-by-step navigation through the sources found
      for (const source of sources.slice(0, 4)) {
        await new Promise(r => setTimeout(r, 1200));
        onLog({
          id: Math.random().toString(),
          type: 'navigate',
          message: `Conectando a ${new URL(source.uri).hostname}...`,
          timestamp: new Date(),
          details: `URL: ${source.uri}`
        });
        
        await new Promise(r => setTimeout(r, 800));
        onLog({
          id: Math.random().toString(),
          type: 'read',
          message: `Extraindo dados e analisando conteúdo de "${source.title}"`,
          timestamp: new Date()
        });
        
        onLog({
          id: Math.random().toString(),
          type: 'click',
          message: `Interagindo com elementos da página para coletar dados secundários...`,
          timestamp: new Date()
        });
      }
    }

    onLog({
      id: Math.random().toString(),
      type: 'think',
      message: `Sintetizando todas as informações coletadas na navegação real...`,
      timestamp: new Date()
    });

    return { text, sources };
  } catch (error) {
    console.error("Gemini Error:", error);
    const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
    onLog({
      id: Math.random().toString(),
      type: 'info',
      message: `FALHA NA NAVEGAÇÃO: ${errorMsg}`,
      timestamp: new Date()
    });
    return { text: "Ocorreu um erro ao tentar navegar na web.", sources: [] };
  }
};
