
export interface ActionLog {
  id: string;
  type: 'think' | 'navigate' | 'click' | 'read' | 'search' | 'info';
  message: string;
  timestamp: Date;
  details?: string;
}

export interface BrowserTab {
  id: string;
  title: string;
  url: string;
  content: string;
  favicon?: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface AgentState {
  currentUrl: string;
  currentTitle: string;
  logs: ActionLog[];
  isThinking: boolean;
  history: string[];
  groundingSources: GroundingSource[];
}
