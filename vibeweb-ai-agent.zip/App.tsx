
import React, { useState, useCallback, useEffect, useRef } from 'react';
// Added RotateCcw to the imports below
import { Send, Zap, Sparkles, Command, Globe, ExternalLink, RotateCcw } from 'lucide-react';
import LogViewer from './components/LogViewer';
import BrowserSimulator from './components/BrowserSimulator';
import { navigateWeb } from './services/geminiService';
import { ActionLog, GroundingSource, AgentState } from './types';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [state, setState] = useState<AgentState>({
    currentUrl: '',
    currentTitle: '',
    logs: [],
    isThinking: false,
    history: [],
    groundingSources: []
  });
  const [lastResult, setLastResult] = useState('');
  const resultRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((log: ActionLog) => {
    setState(prev => ({
      ...prev,
      logs: [...prev.logs, log]
    }));
  }, []);

  const handleSources = useCallback((sources: GroundingSource[]) => {
    setState(prev => ({
      ...prev,
      groundingSources: sources
    }));
  }, []);

  const handleAction = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || state.isThinking) return;

    const currentPrompt = prompt;
    setPrompt('');
    setState(prev => ({
      ...prev,
      isThinking: true,
      currentUrl: 'https://www.google.com/search',
      logs: [],
      groundingSources: []
    }));
    setLastResult('');

    const { text, sources } = await navigateWeb(currentPrompt, addLog, handleSources);

    setLastResult(text);
    setState(prev => ({
      ...prev,
      isThinking: false,
      currentUrl: sources[0]?.uri || 'vibeweb://complete',
      currentTitle: sources[0]?.title || 'Resultado da Navegação'
    }));
  };

  return (
    <div className="flex h-screen w-full bg-[#050505] text-white p-4 gap-4 overflow-hidden selection:bg-indigo-500/30">
      {/* Sidebar / Left Column: Chat & Log */}
      <div className="flex flex-col w-full md:w-[480px] gap-4 h-full">
        {/* Header */}
        <div className="flex items-center justify-between px-2 py-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-2xl shadow-indigo-600/40 border border-white/10 ring-1 ring-indigo-400/50">
              <Zap className="text-white w-6 h-6 fill-current" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tighter bg-gradient-to-r from-white via-white to-white/40 bg-clip-text text-transparent">VIBEWEB</h1>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <p className="text-[9px] uppercase tracking-[0.2em] text-emerald-500/80 font-black">Online Execution</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
            <Globe className="w-3.5 h-3.5 text-white/40" />
            <span className="text-[10px] font-bold text-white/60">LIVE_BROWSER</span>
          </div>
        </div>

        {/* Action Log Visualizer */}
        <div className="flex-1 min-h-0">
          <LogViewer logs={state.logs} />
        </div>

        {/* User Input Area */}
        <div className="bg-[#111] border border-white/10 rounded-2xl p-5 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent" />
          
          <form onSubmit={handleAction} className="relative z-10">
            <div className="absolute left-3.5 top-4 text-indigo-500/50 group-focus-within:text-indigo-400 transition-colors">
              <Command className="w-5 h-5" />
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ex: 'Encontre o preço atual do Bitcoin e as 3 últimas notícias'..."
              className="w-full bg-black/40 border border-white/5 rounded-xl pl-12 pr-14 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600/50 focus:border-transparent resize-none h-28 transition-all placeholder:text-white/20 font-medium"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleAction();
                }
              }}
            />
            <button
              type="submit"
              disabled={state.isThinking || !prompt.trim()}
              className={`absolute right-3 bottom-3 p-3 rounded-xl transition-all ${
                state.isThinking || !prompt.trim() 
                  ? 'bg-white/5 text-white/10 cursor-not-allowed border border-white/5' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-xl shadow-indigo-600/40 border border-indigo-400/50 hover:scale-105 active:scale-95'
              }`}
            >
              {state.isThinking ? (
                <RotateCcw className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </form>
          
          <div className="flex items-center justify-between mt-4 px-1">
            <div className="flex items-center gap-2 text-[10px] text-white/20 font-bold uppercase tracking-wider">
              <Sparkles className="w-3 h-3 text-indigo-500/50" />
              <span>Real-Time Internet Grounding</span>
            </div>
            {state.groundingSources.length > 0 && (
              <div className="text-[10px] text-indigo-400 font-bold">
                {state.groundingSources.length} FONTES CONECTADAS
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main View / Right Column: Browser Visualizer */}
      <div className="hidden md:flex flex-1 h-full min-w-0">
        <BrowserSimulator 
          url={state.currentUrl}
          title={state.currentTitle}
          sources={state.groundingSources}
          isThinking={state.isThinking}
          content={lastResult}
        />
      </div>

      {/* Mobile Disclaimer */}
      <div className="md:hidden fixed inset-0 bg-[#050505] flex flex-col items-center justify-center p-8 text-center z-[100]">
        <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-600/40 mb-8">
           <Zap className="w-10 h-10 text-white fill-current" />
        </div>
        <h2 className="text-3xl font-black mb-4 tracking-tighter">VIBEWEB MOBILE</h2>
        <p className="text-white/50 mb-10 leading-relaxed font-medium">O VibeWeb utiliza um sistema de visualização lado-a-lado otimizado para telas maiores onde você pode ver a navegação em tempo real.</p>
        <button 
          onClick={() => window.location.reload()}
          className="bg-indigo-600 w-full py-4 rounded-2xl font-black shadow-xl shadow-indigo-600/20 active:scale-95 transition-transform"
        >
          TENTAR MESMO ASSIM
        </button>
      </div>
    </div>
  );
};

export default App;
